package com.example.fooddelivery.model

data class CartItem (
    var itemId:String,
    var itemName:String,
    var itemPrice:String,
    var restaurantId:String
)