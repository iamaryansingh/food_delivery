package com.example.fooddelivery.model

class Restaurant (
    val ResturantId:String,
    val RestaurantName: String,
    val RestaurantRating:String,
    val RestaurantPrice:String,
    val RestaurantImage: String

)