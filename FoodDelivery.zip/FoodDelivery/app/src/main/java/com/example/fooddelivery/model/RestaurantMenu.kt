package com.example.fooddelivery.model

class RestaurantMenu (
    var id:String,
    var name:String,
    var cost_for_one:String
    )